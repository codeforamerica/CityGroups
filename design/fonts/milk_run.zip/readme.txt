MILK RUNA true type font by P.D. Magnuswww.fontmonkey.comMilk Run is a handwriting font drawn and edited in TypeTool.
This font is copyright 2004 by P.D. Magnus. 'Milk Run', 'FontMonkey', and 'fecundity.com' are trademarks of P.D. Magnus.
The font is free for non-commercial use. Commercial use would
probably be free, too; contact me for details. The archive
file may be freely distributed provided none of the contents
are altered or removed. Et cetera ad nauseum.version 1.0 - 5ix2004